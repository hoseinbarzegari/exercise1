<?php
$str = 'Life is beautiful depending on how you look at life';
$str2 = strtolower($str);
echo substr_count($str2,'life');

?>