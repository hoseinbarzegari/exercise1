<?php
$str = "test@example.com";
$username = explode("@", $str)[0];
echo $username;
