<?php
$string='Write a PHP script to count the words in the string.';
echo str_word_count($string);
?>
