<?php

# https://quera.org/problemset/2885/

$n = readline();

for ($i = 0; $i < $n; $i++) {
    echo "man khoshghlab hastam\n";
}
