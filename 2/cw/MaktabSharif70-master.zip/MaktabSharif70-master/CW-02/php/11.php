<?php

/*
11. Write a PHP script to count the words in the string.
*/

$str = "Navid Masoudi";
echo str_word_count($str);
