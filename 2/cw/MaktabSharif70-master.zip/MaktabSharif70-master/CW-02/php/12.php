<?php

/*
12.Write a PHP script to convert all the characters inside the string into uppercase.
*/

$str = "Navid Masoudi";
echo strtoupper($str);
