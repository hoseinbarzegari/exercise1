# MaktabSharif70

## [#CW2](CW-02)

## [#CW1](CW-01)

## [#M70_HW1](HW-01)

- CW = ClassWork
- HW = HomeWork

---

#### todo:

- [x] [Complete php homeworks for HW1](HW-01/php)
- [x] [Complete html homeworks for HW1](HW-01/html)
- [x] [Complete web homeworks for HW1](HW-01/web)

---

### Change apache root

You can relocate it by editing the **DocumentRoot** setting in _XAMPP\apache\conf\httpd.conf_ .

It should currently be:

> C:/xampp/htdocs

Change it to:

> C:/Users/PATH/TO/YOUR/DIRECTORY
