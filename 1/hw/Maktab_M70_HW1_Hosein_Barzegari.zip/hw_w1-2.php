<?php
$a =(int)readline('Inter The length of the first side: ');
$b =(int)readline('Inter The length of the second side: ');
$c =(int)readline('Inter The length of the third side: ');
if($a*$a+$b*$b==$c*$c)
echo "yes";
else
    echo "no"

?>