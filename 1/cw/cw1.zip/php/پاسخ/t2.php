<?php
$z1=87;
$z2=65;
$z3=27;
$EZ=$z1+$z2+$z3;
if($EZ==180 && $z1!=0 && $z2!=0 && $z3!=0)
echo 'yes';
else
echo 'no'
?>