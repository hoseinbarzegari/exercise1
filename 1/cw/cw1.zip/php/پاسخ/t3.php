<?php
$st='yekshanbe';
if($st=='shanbe' || $st=='doshanbe' || $st=='chaharshanbe'){
    echo "perspolis";
}
elseif($st=='jome'){
    echo "tatil";
} 
else {
    echo "bahman";
}

?>