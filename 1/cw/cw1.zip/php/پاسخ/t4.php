<?php
$n=50;
for($i=0;$i<$n;$i++)
echo "man khoshghlab hastam";

?>